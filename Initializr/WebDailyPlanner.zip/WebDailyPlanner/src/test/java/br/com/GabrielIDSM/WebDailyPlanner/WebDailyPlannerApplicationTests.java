package br.com.GabrielIDSM.WebDailyPlanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebDailyPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
